package com.example.expert;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpertApplicationTests {

    @Test
    void contextLoads() {
    }

}
