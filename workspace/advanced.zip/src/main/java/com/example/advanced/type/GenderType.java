package com.example.advanced.type;

public enum GenderType {
    MALE, FEMALE
}
